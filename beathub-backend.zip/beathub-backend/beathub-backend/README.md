# BeatHub Backend

A MongoDB/Mongoose schema design for a music streaming application.

## How to Run

1. Install dependencies:
npm install

2. Add MongoDB URI in .env file.

3. Run seed script:
node scripts/seed.js
